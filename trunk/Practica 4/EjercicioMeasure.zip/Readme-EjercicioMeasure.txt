Ver Readme-EjercicioDistance.txt y reemplazar Distance por Measure!!
Este ejercicio por supuesto es un poco mas complicado que el de Distance y el objetivo
el que logren abstraciones mas genericas que las obtenidas en el ejercicio anterior.
Tambien toca algunos temas de implementacion que el ejercicio anterior no lo hace.
