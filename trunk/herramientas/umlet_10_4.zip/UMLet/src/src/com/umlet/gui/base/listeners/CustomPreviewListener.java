package com.umlet.gui.base.listeners;

import com.umlet.control.diagram.DiagramHandler;

public class CustomPreviewListener extends DiagramListener {

	public CustomPreviewListener(DiagramHandler handler) {
		super(handler);
	}
}
